package com.example.kid_d_000.lab13;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by kid_d_000 on 14/02/2018.
 */

public class Nodo {
    TextView texto;
    Nodo sig;

    public Nodo(TextView t) {
        texto = t;
        sig = null;
    }
}
