package mx.edu.ittepic.a225_proyecto_zulmacoronel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Zulma on 14/03/2018.
 */

public class BasedeDatos extends SQLiteOpenHelper {

    public SQLiteDatabase myDB;

    public BasedeDatos(Context context) {
        super(context, "BDobras", null, 1);}
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREAR_TABLA_CLIENTE("CREATE TABLE CLIENTE" +
                "(" +
                "IDCLIENTE INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "NOMBRE VARCHAR(200)," +
                "DOMICILIO VARCHAR(400)," +
                "CELULAR VARCHAR(100)" +
                "DESCRIPCION VARCHAR(100)" +
                "EMAIL VARCHAR(100)" +
                "MONTO FLOAT(100)" +
                "FIN VARCHAR(100)" +
                ")");
        sqLiteDatabase.execSQL(CREAR_TABLA_CLIENTE);
        String CREAR_TABLA_EMPLADO = "" +
                "CREATE TABLE EMPLEADO (" +
                " ID_EMPLEADO  INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NOMBRE TEXT, " +
                "CEL TEXT )";

        sqLiteDatabase.execSQL(CREAR_TABLA_EMPLADO);

        String CREAR_TABLA_OBRA = "" +
                "CREATE TABLE OBRA (" +
                " ID_OBRA  INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "DESCRIPCION TEXT, " +
                "MONTO TEXT, " +
                "FINALIZADA BOOLEAN, " +
                "FECHA_INI DATE, " +
                "FECHA_FIN DATE, " +
                " ID_CLIENTE  INTEGER, FOREIGN KEY(ID_CLIENTE) REFERENCES CLIENTE(ID_CLIENTE))";

        sqLiteDatabase.execSQL(CREAR_TABLA_OBRA);

        String CREAR_TABLA_OBRA_EMPLEADO = "" +
                "CREATE TABLE OBRA_EMPLEADO (" +
                " ID_OBRA_EMPLEADO  INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ACTIVIDAD TEXT, " +
                "PAGO TEXT, " +
                " ID_EMPLEADO  INTEGER ,ID_OBRA  INTEGER , FOREIGN KEY(ID_EMPLEADO) REFERENCES EMPLEADO(ID_EMPLEADO)," +
                "  FOREIGN KEY(ID_OBRA) REFERENCES OBRA(ID_OBRA))";

        sqLiteDatabase.execSQL(CREAR_TABLA_OBRA_EMPLEADO);

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {


