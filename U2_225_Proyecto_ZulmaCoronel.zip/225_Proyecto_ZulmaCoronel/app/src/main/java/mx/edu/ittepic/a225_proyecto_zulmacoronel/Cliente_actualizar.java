package mx.edu.ittepic.a225_proyecto_zulmacoronel;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Cliente_actualizar extends AppCompatActivity {
    Button btnModificar, btnRegresar;
    EditText txtNombre, txtDomicilio, txtCelular, txtCorreo, txtDescripcion, txtMonto, txtFin, txtidClientes;
    BasedeDatos bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cliente_actualizar);

        txtNombre = findViewById(R.id.nombre);
        txtCelular = findViewById(R.id.celular);
        txtDomicilio = findViewById(R.id.domicilio);
        txtCorreo = findViewById(R.id.correo);
        txtDescripcion = findViewById(R.id.descripcion);
        txtMonto = findViewById(R.id.monto);
        txtFin = findViewById(R.id.finobra);

        btnModificar = findViewById(R.id.btnmodificar);
        btnRegresar = findViewById(R.id.btnregresar);

        bd = new BasedeDatos(this,"BASE", null,1);

        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Modificar(txtNombre,txtDomicilio,txtCelular,txtidClientes);
            }
        });

        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void Modificar(EditText nom, EditText dom, EditText cel,EditText cor, EditText des, EditText mon, EditText fin, EditText id){
        Cliente_insertar a = new Cliente_insertar();
        try{
            if(a.vacio(nom) || a.vacio(dom) || a.vacio(cel) || a.vacio(id)){
                Toast.makeText(Cliente_actualizar.this, "Uno o mas no se han completado", Toast.LENGTH_SHORT).show();
            }
            else{
                if(!idFound(txtidClientes)){
                    Toast.makeText(this, "El id no se ha registrado", Toast.LENGTH_SHORT).show();
                }
                else{
                    SQLiteDatabase database = bd.getWritableDatabase();
                    String SQL ="UPDATE CLIENTE " +
                            "SET NOMBRE='"+a.cad(nom)+"', " +
                            "DOMICILIO='"+a.cad(dom)+"', " +
                            "CELULAR='"+a.cad(cel)+"'"+
                            "E-MAIL='"+a.cad(cor)+"'"+
                            "DESCRIPCION='"+a.cad(des)+"'"+
                            "MONTO='"+a.cad(mon)+"'"+
                            "FINALIZADA='"+a.cad(fin)+"'"+

                            "WHERE IDCLIENTE="+a.cad(id);
                    database.execSQL(SQL);
                    Toast.makeText(Cliente_actualizar.this, "REGISTRO MODIFICADO EXITOSAMENTE", Toast.LENGTH_SHORT).show();
                }
            }
        }catch (SQLiteException e){
            Toast.makeText(Cliente_actualizar.this, ""+e, Toast.LENGTH_SHORT).show();
        }
    }

    public boolean idFound(EditText edt){
        try{
            SQLiteDatabase databse = bd.getReadableDatabase();
            String SQL = "SELECT IDCLIENTE FROM CLIENTE WHERE IDCLIENTE="+edt.getText().toString();

            Cursor c = databse.rawQuery(SQL,null);

            if(c.moveToFirst()){
                return true;
            }
            else{
                return false;
            }

        }catch(SQLiteException e){
            Toast.makeText(this, ""+e, Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}
