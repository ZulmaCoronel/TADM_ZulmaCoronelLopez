package mx.edu.ittepic.a225_proyecto_zulmacoronel;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Clientes_menu extends AppCompatActivity {
    Button btnInsertar,btnModificar,btnConsultar,btnRregresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes_menu);

        btnInsertar = findViewById(R.id.btninsertar);
        btnModificar=findViewById(R.id.btnmodificar);
        btnConsultar = findViewById(R.id.btnconsultar);
        btnRregresar = findViewById(R.id.btnregresar);


        btnInsertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent insert = new Intent(Clientes_menu.this,Cliente_insertar.class);
                startActivity(insert);
            }
        });
        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent update = new Intent(Clientes_menu.this,Cliente_actualizar.class);
                startActivity(update);
            }
        });

        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent select = new Intent(Clientes_menu.this,Cliente_consultar.class);
                startActivity(select);
            }
        });

        btnRregresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}

