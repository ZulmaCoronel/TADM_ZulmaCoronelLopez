package mx.edu.ittepic.tdm_calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn0;
    Button btn1;
    Button btn2;
    Button btn3;
    Button btn4;
    Button btn5;
    Button btn6;
    Button btn7;
    Button btn8;
    Button btn9;
    Button btnsuma;
    Button btnresta;
    Button btnmultiplicacion;
    Button btndivision;
    Button btnigual;
    Button btnpunto;
    Button limpiar;

    TextView barra1;

    double num1,num2;
    double res;
    String n1="";

    int cont=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn0 = (Button)findViewById(R.id.num0);
        btn1 = (Button)findViewById(R.id.num1);
        btn2 = (Button)findViewById(R.id.num2);
        btn3 = (Button)findViewById(R.id.num3);
        btn4 = (Button)findViewById(R.id.num4);
        btn5 = (Button)findViewById(R.id.num5);
        btn6 = (Button)findViewById(R.id.num6);
        btn7 = (Button)findViewById(R.id.num7);
        btn8 = (Button)findViewById(R.id.num8);
        btn9 = (Button)findViewById(R.id.num9);

        btnpunto =(Button) findViewById(R.id.btnpunto);
        btnigual =(Button) findViewById(R.id.btnigual);
        limpiar = (Button)findViewById(R.id.btnborrar);

        btnsuma = (Button)findViewById(R.id.btnsumar);
        btnresta = (Button)findViewById(R.id.btnrestar);
        btnmultiplicacion = (Button)findViewById(R.id.btnmultiplicar);
        btndivision =(Button) findViewById(R.id.btndividir);

        barra1 =(TextView) findViewById(R.id.txtresultado);

        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"0";
                barra1.setText(n1);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"1";
                barra1.setText(n1);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"2";
                barra1.setText(n1);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"3";
                barra1.setText(n1);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"4";
                barra1.setText(n1);
            }
        });

        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"5";
                barra1.setText(n1);
            }
        });

        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"6";
                barra1.setText(n1);
            }
        });

        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"7";
                barra1.setText(n1);
            }
        });

        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"8";
                barra1.setText(n1);
            }
        });

        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+"9";
                barra1.setText(n1);
            }
        });
        btnpunto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                n1=n1+".";
                barra1.setText(n1);
            }
        });

        btnsuma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try{

                    String temporal = barra1.getText().toString();
                    num1= Double.parseDouble(temporal);


                }catch (NumberFormatException e){

                    Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                cont=1;
                barra1.setText("");
                n1="";
            }
        });

        btnresta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    String temporal = barra1.getText().toString();
                    num1= Double.parseDouble(temporal);

                }catch (NumberFormatException e){

                    Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                cont=2;
                barra1.setText("");
                n1="";
            }
        });

        btnmultiplicacion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    String temporal = barra1.getText().toString();
                    num1= Double.parseDouble(temporal);

                }catch (NumberFormatException e){

                    Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                cont=3;
                barra1.setText("");
                n1="";
            }
        });

        btndivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    String temporal = barra1.getText().toString();
                    num1= Double.parseDouble(temporal);

                }catch (NumberFormatException e){

                    Toast.makeText(MainActivity.this,e.getMessage(), Toast.LENGTH_SHORT).show();
                }

                cont=4;
                barra1.setText("");
                n1="";
            }
        });


        btnigual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temporal = barra1.getText().toString();
                num2=Double.parseDouble(temporal);

                switch (cont){
                    case 1:
                        res=num1+num2;
                        break;
                    case 2:
                        res=num1-num2;
                        break;
                    case 3:
                        res=num1*num2;
                        break;
                    case 4:
                        res=num1/num2;
                        break;
                }

                barra1.setText(""+res);


            }
        });

        limpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                barra1.setText("");
                num1=0;
                num2=0;
                n1="";
                res=0;
            }
        });

    }
}
