package mx.edu.ittepic.u3_31_json_clima_zulmacoronel;

/**
 * Created by Zulma on 21/03/2018.
 */

public class AsyncResponse {
    void procesarRespuesta(String r);
}
