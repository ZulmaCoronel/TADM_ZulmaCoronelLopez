package mx.edu.ittepic.u5_contadorpasos;

/**
 * Created by Zulma on 17/05/2018.
 */

public class StepListener {
    public void step(long timeNs);
}