package mx.edu.ittepic.a225_proyectofinal_zulma.Activitys;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Zulma on 15/03/2018.
 */

public class AdaptadorEmpleado extends RecyclerView.Adapter<AdaptadorEmpleado.MyViewHolder> {
    private Activity activity;
    private ArrayList<Empleado> list;
    private AlertDialog dialog;
    private Empleados cWorkers;
    private Detalle_obra cDetalle_obra;
    private AdaptadorEmpleado.OnItemClickListener mListener;

    public interface OnItemClickListener{
        void onItemClick(int position);
    }

    public void setOnItemClickListener(AdaptadorEmpleado.OnItemClickListener listener){
        mListener = listener;
    }

    public  AdaptadorEmpleado(Activity activity, ArrayList<Empleado> list,Empleados workers){
        this.activity = activity;
        this.list = list;
        cWorkers = workers;
    }
    public  AdaptadorEmpleado(Activity activity, ArrayList<Empleado> list,Detalle_obra detalle_obra){
        this.activity = activity;
        this.list = list;
        cDetalle_obra = detalle_obra;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context;
        context =parent.getContext();

        LayoutInflater inflater;
        inflater = LayoutInflater.from(context);
        View itemView;
        if(cWorkers!=null){
            itemView = inflater.inflate(R.layout.empleado,parent,false);
        }
        else{
            itemView = inflater.inflate(R.layout.empleado_alone,parent,false);
        }


        return new AdaptadorEmpleado.MyViewHolder(itemView,mListener);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        final Empleado worker = list.get(position);

        holder.txtNombre.setText("Nombre: "+worker.getNombreTrabajador());
        holder.txtActividad.setText("Actividad: "+worker.getActividadTrabajador());
        holder.txtCelular.setText("Celular: "+worker.getCelularTrabajador());
        if(cWorkers!=null){
            holder.btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Open edition window
                    final int id = worker.getIdTrabajador();


                    LayoutInflater layoutInflater = activity.getLayoutInflater();
                    View view1 = layoutInflater.inflate(R.layout.editar_empleado,null);

                    final EditText input_nombre = (EditText) view1.findViewById(R.id.nombre);
                    final EditText input_actividad = (EditText) view1.findViewById(R.id.actividad);
                    final EditText input_celular = (EditText) view1.findViewById(R.id.celular);

                    final Button btnSave = (Button) view1.findViewById(R.id.btnGuardar);


                    AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                    builder.setView(view1).setTitle("Edit Records").setNegativeButton("close", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            dialog.dismiss();
                        }
                    });

                    final BaseDatos _dbFunctions = new BaseDatos(activity);
                    final Empleado _worker = _dbFunctions.getSingleWorker(id);
                    input_nombre.setText(_worker.getNombreTrabajador());
                    input_actividad.setText(_worker.getActividadTrabajador());
                    input_celular.setText(_worker.getCelularTrabajador());


                    btnSave.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            String nombre = input_nombre.getText().toString();
                            String actividad = input_actividad.getText().toString();
                            String celular = input_celular.getText().toString();


                            _worker.setNombreTrabajador(nombre);
                            _worker.setActividadTrabajador(actividad);
                            _worker.setCelularTrabajador(celular);


                            _dbFunctions.UpdateWorker(_worker);

                            Toast.makeText(activity, nombre + " updated.", Toast.LENGTH_SHORT).show();
                            ((Empleados)activity).fetchWorkersRecords();
                            dialog.dismiss();
                        }
                    });
                    dialog = builder.create();
                    dialog.show();
                }
            });
            holder.btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Delete worker
                    final BaseDatos _dbFunctions = new BaseDatos(activity);
                    final int id = worker.getIdTrabajador();
                    _dbFunctions.DeleteWorker(id);

                    Toast.makeText(activity,  " Eliminado...", Toast.LENGTH_SHORT).show();
                    ((Empleados)activity).fetchWorkersRecords();
                    //dialog.dismiss();

                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView txtNombre, txtActividad, txtCelular;
        TextView btnEdit, btnDelete;

        public MyViewHolder(View itemView, final AdaptadorEmpleado.OnItemClickListener listener) {
            super(itemView);

            txtNombre = this.itemView.findViewById(R.id.nombre);
            txtActividad = this.itemView.findViewById(R.id.actividad);
            txtCelular = this.itemView.findViewById(R.id.celular);
            if(cWorkers!=null){
                btnEdit = this.itemView.findViewById(R.id.btnEdit);
                btnDelete = this.itemView.findViewById(R.id.btnDelete);
            }
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
}

