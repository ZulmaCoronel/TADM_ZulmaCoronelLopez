package mx.edu.ittepic.a225_proyectofinal_zulma.Activitys;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import mx.edu.ittepic.a225_proyectofinal_zulma.R;

public class Principal_menu extends AppCompatActivity {

    Button btnEmpleados,btnSalir, btnObras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_menu);

        btnEmpleados = findViewById(R.id.btnEmpleados);
        btnSalir= findViewById(R.id.btnSalir);
        btnObras= findViewById(R.id.btnObras);

        btnEmpleados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent insert = new Intent(Principal_menu.this,Empleados.class);
                startActivity(insert);
            }
        });
        btnObras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent update = new Intent(Principal_menu.this,Obras.class);
                startActivity(update);
            }
        });
        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
            });
    }

    void fnStrartingButtons(){
        btnSalir = findViewById(R.id.btnSalir);
        btnObras = findViewById(R.id.btnObras);
        btnEmpleados = findViewById(R.id.btnEmpleados);
    }
}
