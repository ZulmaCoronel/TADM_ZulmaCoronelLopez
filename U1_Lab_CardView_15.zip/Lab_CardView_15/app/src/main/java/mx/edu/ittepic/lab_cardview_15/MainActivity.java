package mx.edu.ittepic.lab_cardview_15;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.AdapterView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    ArrayList<musica> listaMusica;
    RecyclerView listaObjetos;
    private RecyclerView.LayoutManager mLayoutManager;
    Adaptador adapter;

    String[] tipoGenero = {"Folklorica", "Rock Alternativo", "Acusticos", "jockm","wefcnoiewf"};

    String[] nombreCancion = {"Sones de Hueasteca", "Urbano Argentino", "Concierto de trova","cnjcwj","niufciuw"};
    int[] ColorArreglo = {Color.rgb(154, 133, 239),
                            Color.rgb(47,186,126),
                            Color.rgb(79,199,218),
                            Color.rgb(45,136,229),
            Color.rgb(65,246,129)};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaObjetos = (RecyclerView) findViewById(R.id.caview);
        listaObjetos.setLayoutManager(new LinearLayoutManager(this));
        listaMusica= new ArrayList<>();
        obtenerMusica();

        adapter = new Adaptador(listaMusica, getApplicationContext());
        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        listaObjetos.setAdapter(adapter);
    }

    public void obtenerMusica() {
        for (int i = 0; i < tipoGenero.length; i++) {
            listaMusica.add(new musica(1, tipoGenero[i], nombreCancion[i], "@drawable/p", ColorArreglo[i]));
        }

    }
}
